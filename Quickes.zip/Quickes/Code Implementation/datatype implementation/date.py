from datetime import date
print(date.today())